package com.example.flashlight

import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.view.WindowManager
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {

    private lateinit var cameraManager: CameraManager
    private lateinit var toggleButton: MaterialButton
    private lateinit var slider: Slider
    private lateinit var percentText: TextView
    private lateinit var statusText: TextView

    // مورس
    private lateinit var morseInput: EditText
    private lateinit var speedSlider: Slider
    private lateinit var speedText: TextView
    private lateinit var morseButton: MaterialButton

    private var cameraId: String? = null
    private var maxLevel = 1
    private var level = 1
    private var torchOn = false

    @Volatile
    private var sending = false
    private var morseThread: Thread? = null

    // وضعیت چراغ قوه را با خود سیستم هماهنگ نگه می‌دارد
    // (مثلاً اگر از پنل اعلان‌ها خاموش شد، دکمه هم به‌روز می‌شود)
    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) {
            if (id != cameraId) return
            torchOn = enabled
            updateUi()
        }

        override fun onTorchStrengthLevelChanged(id: String, newStrengthLevel: Int) {
            if (id != cameraId) return
            level = newStrengthLevel
            updateUi()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toggleButton = findViewById(R.id.toggleButton)
        slider = findViewById(R.id.brightnessSlider)
        percentText = findViewById(R.id.brightnessPercent)
        statusText = findViewById(R.id.statusMessage)
        morseInput = findViewById(R.id.morseInput)
        speedSlider = findViewById(R.id.speedSlider)
        speedText = findViewById(R.id.speedText)
        morseButton = findViewById(R.id.morseButton)

        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager

        if (!findFlashCamera()) {
            showStatus(getString(R.string.no_flash))
            toggleButton.isEnabled = false
            slider.isEnabled = false
            morseButton.isEnabled = false
            morseInput.isEnabled = false
            speedSlider.isEnabled = false
            return
        }

        setupSlider()
        setupMorse()

        toggleButton.setOnClickListener { applyTorch(!torchOn) }
    }

    override fun onStart() {
        super.onStart()
        if (cameraId != null) cameraManager.registerTorchCallback(torchCallback, null)
    }

    override fun onStop() {
        super.onStop()
        // با رفتن به پس‌زمینه ارسال مورس متوقف می‌شود
        stopMorse()
        if (cameraId != null) cameraManager.unregisterTorchCallback(torchCallback)
    }

    /** دوربین پشتی که فلش دارد را پیدا می‌کند و بیشینه‌ی سطح نور را می‌خواند. */
    private fun findFlashCamera(): Boolean {
        for (id in cameraManager.cameraIdList) {
            val c = cameraManager.getCameraCharacteristics(id)
            val hasFlash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            val facing = c.get(CameraCharacteristics.LENS_FACING)
            if (hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK) {
                cameraId = id
                maxLevel = c.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                level = c.get(CameraCharacteristics.FLASH_INFO_STRENGTH_DEFAULT_LEVEL) ?: maxLevel
                return true
            }
        }
        return false
    }

    private fun setupSlider() {
        if (maxLevel <= 1) {
            // این گوشی فقط یک سطح نور دارد
            slider.isEnabled = false
            slider.valueFrom = 0f
            slider.valueTo = 1f
            slider.value = 1f
            percentText.text = "100%"
            showStatus(getString(R.string.no_strength_support))
            return
        }

        slider.valueFrom = 1f
        slider.valueTo = maxLevel.toFloat()
        slider.stepSize = 1f
        slider.value = level.coerceIn(1, maxLevel).toFloat()
        slider.setLabelFormatter { v -> "${toPercent(v.toInt())}%" }

        slider.addOnChangeListener { _, value, fromUser ->
            if (!fromUser) return@addOnChangeListener
            level = value.toInt()
            percentText.text = "${toPercent(level)}%"
            // اگر چراغ روشن است (و مورس در حال ارسال نیست) شدت جدید همان لحظه اعمال شود
            if (torchOn && !sending) applyTorch(on = true)
        }
        percentText.text = "${toPercent(level)}%"
    }

    // ---------------------------------------------------------------- مورس

    private fun setupMorse() {
        speedText.text = getString(R.string.speed_label, speedSlider.value.toInt())
        speedSlider.addOnChangeListener { _, value, _ ->
            speedText.text = getString(R.string.speed_label, value.toInt())
        }

        morseButton.setOnClickListener {
            if (sending) stopMorse() else startMorse()
        }
    }

    private fun startMorse() {
        val raw = morseInput.text.toString().trim()
        if (raw.isEmpty()) {
            showStatus(getString(R.string.morse_empty))
            return
        }

        val (steps, skipped) = buildSteps(raw, speedSlider.value.toLong())
        if (steps.isEmpty()) {
            showStatus(getString(R.string.morse_nothing_valid))
            return
        }
        if (skipped > 0) showStatus(getString(R.string.morse_skipped, skipped)) else hideStatus()

        sending = true
        updateMorseUi()

        morseThread = Thread {
            try {
                for ((on, ms) in steps) {
                    applyTorch(on)
                    Thread.sleep(ms)
                }
            } catch (_: InterruptedException) {
                // کاربر ارسال را متوقف کرد
            } finally {
                applyTorch(false)
                runOnUiThread {
                    sending = false
                    updateMorseUi()
                }
            }
        }.also { it.start() }
    }

    private fun stopMorse() {
        morseThread?.interrupt()
        morseThread = null
    }

    /**
     * متن را به دنباله‌ای از (روشن/خاموش، مدت‌زمان) تبدیل می‌کند.
     * زمان‌بندی استاندارد ITU:
     *  نقطه = ۱ واحد، خط تیره = ۳ واحد، فاصله‌ی بین اجزای یک حرف = ۱ واحد،
     *  بین حروف = ۳ واحد، بین کلمات = ۷ واحد.
     * خروجی دوم تعداد نویسه‌های پشتیبانی‌نشده است که نادیده گرفته شدند.
     */
    private fun buildSteps(text: String, unit: Long): Pair<List<Pair<Boolean, Long>>, Int> {
        val steps = ArrayList<Pair<Boolean, Long>>()
        var skipped = 0
        val words = normalize(text).split(Regex("\\s+")).filter { it.isNotEmpty() }

        var firstWord = true
        for (word in words) {
            val codes = ArrayList<String>()
            for (ch in word) {
                val code = MORSE[ch]
                if (code == null) skipped++ else codes.add(code)
            }
            if (codes.isEmpty()) continue

            if (!firstWord) steps.add(false to unit * 7)
            firstWord = false

            codes.forEachIndexed { i, code ->
                if (i > 0) steps.add(false to unit * 3)
                code.forEachIndexed { j, symbol ->
                    if (j > 0) steps.add(false to unit)
                    steps.add(true to if (symbol == '.') unit else unit * 3)
                }
            }
        }
        return steps to skipped
    }

    /** حروف را بزرگ می‌کند و ارقام فارسی و عربی را به لاتین تبدیل می‌کند. */
    private fun normalize(text: String): String {
        val sb = StringBuilder()
        for (ch in text.uppercase()) {
            sb.append(
                when (ch) {
                    in '۰'..'۹' -> '0' + (ch - '۰')
                    in '٠'..'٩' -> '0' + (ch - '٠')
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    private fun updateMorseUi() {
        morseButton.setText(if (sending) R.string.stop_morse else R.string.send_morse)
        toggleButton.isEnabled = !sending
        morseInput.isEnabled = !sending
        if (sending) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // ----------------------------------------------------------- چراغ قوه

    private fun applyTorch(on: Boolean) {
        val id = cameraId ?: return
        try {
            if (on) {
                if (maxLevel > 1) {
                    cameraManager.turnOnTorchWithStrengthLevel(id, level.coerceIn(1, maxLevel))
                } else {
                    cameraManager.setTorchMode(id, true)
                }
            } else {
                cameraManager.setTorchMode(id, false)
            }
        } catch (e: CameraAccessException) {
            runOnUiThread { showStatus(getString(R.string.torch_error)) }
        } catch (e: IllegalArgumentException) {
            runOnUiThread { showStatus(getString(R.string.torch_error)) }
        }
    }

    private fun updateUi() {
        toggleButton.setText(if (torchOn) R.string.turn_off else R.string.turn_on)
        if (maxLevel > 1) {
            val clamped = level.coerceIn(1, maxLevel)
            if (slider.value != clamped.toFloat()) slider.value = clamped.toFloat()
            percentText.text = "${toPercent(clamped)}%"
        }
    }

    private fun toPercent(lvl: Int): Int =
        if (maxLevel <= 1) 100 else (lvl * 100f / maxLevel).toInt()

    private fun showStatus(msg: String) {
        statusText.text = msg
        statusText.visibility = TextView.VISIBLE
    }

    private fun hideStatus() {
        statusText.visibility = TextView.GONE
    }

    companion object {
        private val MORSE: Map<Char, String> = mapOf(
            'A' to ".-", 'B' to "-...", 'C' to "-.-.", 'D' to "-..", 'E' to ".",
            'F' to "..-.", 'G' to "--.", 'H' to "....", 'I' to "..", 'J' to ".---",
            'K' to "-.-", 'L' to ".-..", 'M' to "--", 'N' to "-.", 'O' to "---",
            'P' to ".--.", 'Q' to "--.-", 'R' to ".-.", 'S' to "...", 'T' to "-",
            'U' to "..-", 'V' to "...-", 'W' to ".--", 'X' to "-..-", 'Y' to "-.--",
            'Z' to "--..",
            '0' to "-----", '1' to ".----", '2' to "..---", '3' to "...--", '4' to "....-",
            '5' to ".....", '6' to "-....", '7' to "--...", '8' to "---..", '9' to "----.",
            '.' to ".-.-.-", ',' to "--..--", '?' to "..--..", '\'' to ".----.",
            '!' to "-.-.--", '/' to "-..-.", '(' to "-.--.", ')' to "-.--.-",
            '&' to ".-...", ':' to "---...", ';' to "-.-.-.", '=' to "-...-",
            '+' to ".-.-.", '-' to "-....-", '_' to "..--.-", '"' to ".-..-.",
            '$' to "...-..-", '@' to ".--.-."
        )
    }
}
